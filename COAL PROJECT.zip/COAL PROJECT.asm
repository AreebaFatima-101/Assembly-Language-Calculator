#                             =========================================AREEBA FATIMA (03_134242_101) BSCS 4-(A)==============================================
#                                                                   ============================================
#                                                                        CONSOLE BASED CALCULATOR (RISC-V)
#                                                                   ============================================
# Features:
# ------- Add, Subtract, Multiply, Divide----------
# ------------ Power (Bonus Feature)-------------
# --------- Reuse Previous Result (Bonus)------------
# ------Handles invalid input & divide by zero--------
# ---------- Runs in continuous loop------------


.data
menu:        .asciz "\n====================== CALCULATOR ======================\n1.Add\n2.Sub\n3.Mul\n4.Div\n5.Power\n6.Use Previous Result\n7.Exit\nChoice: "
input1:      .asciz "Enter first number: "
input2:      .asciz "Enter second number: "
resultMsg:   .asciz "Result: "
errorDiv:    .asciz "Error: Division by zero!\n"
invalidMsg:  .asciz "Invalid choice! Try again.\n"
prevMenu: .asciz "\nUse Previous Result:\n1.Add\n2.Sub\n3.Mul\n4.Div\nChoice: "
lastResult:  .word 0     # stores previous result

.text
.globl main

# ============================================
#                  MAIN LOOP 
# ============================================
main:
loop:
    # Show menu
    li a7, 4
    la a0, menu
    ecall

    # Take user input
    li a7, 5
    ecall
    mv t0, a0        # store choice

    # Check all options one by one
    li t1, 1
    beq t0, t1, addition

    li t1, 2
    beq t0, t1, subtraction

    li t1, 3
    beq t0, t1, multiplication

    li t1, 4
    beq t0, t1, division

    li t1, 5
    beq t0, t1, power

    li t1, 6
    beq t0, t1, use_previous

    li t1, 7
    beq t0, t1, exit

    # If nonthing matched
    li a7, 4
    la a0, invalidMsg
    ecall
    j loop


# ============================================
#           FUNCTION: TAKE INPUTS 
# ============================================
get_inputs:
    # Ask first number
    li a7, 4
    la a0, input1
    ecall

    li a7, 5
    ecall
    mv t1, a0

    # Ask second number
    li a7, 4
    la a0, input2
    ecall

    li a7, 5
    ecall
    mv t2, a0

    ret


# ============================================
#                  ADDITION
# ============================================
addition:
    jal get_inputs       # reuse input function

    add t3, t1, t2       # t3 = t1 + t2

    j print_result


# ============================================
#                 SUBTRACTION
# ============================================
subtraction:
    jal get_inputs

    sub t3, t1, t2       # t3 = t1 - t2

    j print_result


# ============================================
#                MULTIPLICATION
# ============================================
multiplication:
    jal get_inputs

    mul t3, t1, t2       # t3 = t1 * t2

    j print_result


# ============================================
#                 DIVISION 
# ============================================
division:
    jal get_inputs

    beq t2, zero, div_error   # check divide by zero

    div t3, t1, t2

    j print_result

div_error:
    li a7, 4
    la a0, errorDiv
    ecall
    j loop


# ============================================
#            POWER (Bonus)
# ============================================
power:
    jal get_inputs

    li t3, 1            # result = 1

power_loop:
    beqz t2, power_done
    mul t3, t3, t1      # result *= base
    addi t2, t2, -1
    j power_loop

power_done:
    j print_result


# ============================================
#        USE PREVIOUS RESULT (Bonus)
# ============================================
use_previous:
    # Load previous result
    la t4, lastResult
    lw t1, 0(t4)

    # Show operation menu
    li a7, 4
    la a0, prevMenu
    ecall

    # Take operation choice
    li a7, 5
    ecall
    mv t0, a0

    # Ask for second number
    li a7, 4
    la a0, input2
    ecall

    li a7, 5
    ecall
    mv t2, a0

    # Check operation again 
    li t5, 1
    beq t0, t5, prev_add

    li t5, 2
    beq t0, t5, prev_sub

    li t5, 3
    beq t0, t5, prev_mul

    li t5, 4
    beq t0, t5, prev_div

    # Invalid choice
    li a7, 4
    la a0, invalidMsg
    ecall
    j loop


# ===== OPERATIONS WITH PREVIOUS =====

prev_add:
    add t3, t1, t2
    j print_result

prev_sub:
    sub t3, t1, t2
    j print_result

prev_mul:
    mul t3, t1, t2
    j print_result

prev_div:
    beq t2, zero, div_error
    div t3, t1, t2
    j print_result

# ============================================
#                PRINT RESULT 
# ============================================
print_result:
    # Print message
    li a7, 4
    la a0, resultMsg
    ecall

    # Print value
    li a7, 1
    mv a0, t3
    ecall

    # Save result for reuse it later
    la t4, lastResult
    sw t3, 0(t4)
  
    

    j loop


# ============================================
#               EXIT PROGRAM
# ============================================
exit:
    li a7, 10
    ecall
